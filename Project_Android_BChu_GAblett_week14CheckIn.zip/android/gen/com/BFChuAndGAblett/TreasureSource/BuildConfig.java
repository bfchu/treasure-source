/** Automatically generated file. DO NOT MODIFY */
package com.BFChuAndGAblett.TreasureSource;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}